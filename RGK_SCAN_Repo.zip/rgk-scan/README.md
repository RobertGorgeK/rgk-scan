RGK SCAN Protocol - Installation & Setup Guide

---

Purpose:
This document provides step-by-step instructions for replicating the RGK SCAN Protocol on any local computer. The RGK SCAN Protocol is a custom daily market scanning tool used to identify high-probability stock and options trades based on technical signals, real-time data, and event-driven setups.

---

Key Features of RGK SCAN:
1. Pre-market scanner for social sentiment, analyst ratings, and unusual volume.
2. Daily MACD crossover detection and VWAP trend analysis.
3. RSI confirmation with short squeeze alerts.
4. Real-time trade recommendations with strike, premium, Greeks.
5. DDEP (Deep Dive Event Probability) integration for catalysts.
6. Automated alerts for breakeven, +50%, and +100% profit.
7. Visual chart overlays with MACD, RSI, and VWAP confirmation.
8. Auto-logging of trades to CSV tracker.

---

Prerequisites:
- Operating System: Windows 10 or later / macOS 11+ / Linux
- Python Version: 3.9 or higher
- Python Packages:
  - pandas
  - numpy
  - yfinance
  - matplotlib
  - ta (technical analysis indicators)
  - requests
  - beautifulsoup4
  - schedule
  - selenium (for live browser scrapes)

---

Step 1: Install Python
1. Download and install Python 3.9+ from: https://www.python.org/downloads/
2. During installation, ensure "Add Python to PATH" is selected.

---

Step 2: Clone or Download RGK SCAN Repository
1. Clone via Git:
   git clone https://github.com/YOURUSERNAME/rgk-scan.git
   or manually download the ZIP archive and extract.

---

Step 3: Install Dependencies
In terminal or command prompt:
pip install -r requirements.txt

---

Step 4: Configure Watchlist
Edit watchlist.json to include tickers of interest, like:
{
  "tickers": ["DPRO", "LCID", "AIRO", "SLV", "GLD"]
}

---

Step 5: Run RGK SCAN Daily
python rgk_scan.py
You can schedule this to run at 8:45 AM CT daily via Task Scheduler (Windows) or cron (macOS/Linux).

---

Step 6: Output Files
- Trade Tracker: trade_log.csv
- Charts: Saved in /charts/ folder with ticker + timestamp
- Alerts: Real-time console outputs or optional email/SMS integration

---

Optional: Alert Configuration
In config.json, enable:
{
  "alerts": true,
  "email": "your-email@example.com",
  "sms": "+15555551234"
}

---

Licensing & Distribution
RGK SCAN Protocol is for personal use. Redistribution requires permission.

For support or updates, contact: robert@rgkscantrading.com

---
End of File
