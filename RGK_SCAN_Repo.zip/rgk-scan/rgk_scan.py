# RGK SCAN main script
print('Running RGK SCAN Protocol...')